function defaultTask(cb) {
  // place code for your default task here
  cb();
}

exports.default = defaultTask