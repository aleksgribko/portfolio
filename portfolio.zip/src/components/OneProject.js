import React from 'react'
import '../css/oneProject.css'

export default function OneProject(props){



	return(
		<div id={props.id} className='projectPage'>
					
		</div>
	)
}