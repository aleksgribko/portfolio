import React from 'react'
import '../css/overlay.css'

export default function Overlay(props){
	
	//props.id

	return(		
		<div id={props.id} style={{'display':'none'}} class='overlay'>				
				
		</div>			
	)
}