import React from 'react'

export default function HelloInfo(){

	return(
		<div>			
			<h4>Aleksandr Gribko</h4>
			<h4>Front-end developer</h4>
			<p>Hi and welcome to my portfolio/cv website</p>
			<p>Scroll down to see some of my projects and experience</p>
		</div>
	)
}